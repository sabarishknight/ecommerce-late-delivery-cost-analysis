# The Broken Promise Tax
### What a late delivery *really* costs a marketplace: causal evidence from 96,203 Olist orders

**Sabarish G** · MSc Business Analytics · `SQL` `Python` `Causal inference` `Machine learning` `Data storytelling`

> Marketplaces spend heavily on delivering *faster*. But customers don't see speed. They see whether you **kept your word**.
> This project separates the cost of *being slow* from the cost of *breaking a promise*, prices it, and turns it into a ranked action list.

---

## Key findings

| # | Finding | Evidence |
|---|---|---|
| 1 | Olist over-promises **and** still misses: the median order arrives **12 days early**, yet **6.8%** arrive late | Promise-gap analysis, 96,203 delivered orders |
| 2 | **No cliff, a slide.** No significant ratings jump at the promised date (-0.03★, CI -0.18 to +0.11), but **-0.48★ per extra day late** | Regression discontinuity + placebo, donut, density and covariate-balance tests |
| 3 | **The survey clock is the mechanism:** 94% of orders 3+ days late are rated *before the parcel arrives* | Review-timestamp forensics; Portuguese text mining (*"não recebi"* = "I didn't receive") |
| 4 | Lateness **causes** a **-1.98★** drop per late order (CI -2.03 to -1.94) and **+47 pp** 1-star reviews | 5 estimators agree: OLS + FE, seller fixed effects, propensity matching, doubly-robust AIPW |
| 5 | The repeat-revenue cost is small (**R$0–7,204/yr**) because only 3.0% of customers ever return. **The real cost is reputation: ~11,432 stars and ~2,709 extra 1-star reviews a year** | Kaplan–Meier survival + doubly-robust repeat-purchase model |
| 6 | **Lateness lives in routes, not sellers** (year-over-year r = 0.73 vs 0.14) | Out-of-time persistence test, 2017 → 2018 |
| 7 | Late orders are **predictable at carrier handoff**: the riskiest 10% contain **33%** of late orders (ROC-AUC 0.73) | Gradient boosting, trained on 2017 and tested on unseen 2018 data |
| 8 | A **quantile-regression promise engine** cuts lateness from 7.7% to 6.6% at the same average promise length | Promise frontier on unseen 2018 orders |

## Recommendations (to a fictional Head of Ops / Finance)

1. **Send the review survey only after delivery is confirmed.** A low-effort config change that protects up to ~5,042★ a year (an upper bound).
2. **Handoff rescue queue.** Auto-flag the riskiest 10% of parcels for expedite, re-routing or a proactive customer message. At 50% intervention success that's about 942 fewer late orders a year.
3. **Route-aware promise engine**, retrained monthly: about 863 fewer late orders a year at today's average promise length.
4. **Carrier SLAs on the top São Paulo-origin routes.** The top 12 routes carried 67% of 2018 late orders.
5. **Enforce seller dispatch deadlines.** A missed deadline means 21.1% late vs 5.4%.

## What's inside

```
├── The_Broken_Promise_Tax.ipynb   ← the analysis (executed, all outputs embedded)
├── The_Broken_Promise_Tax.html    ← same notebook as a styled web report (code folded)
├── sql/                           ← staging, dimension and fact models (SQLite; BigQuery-portable)
├── outputs/
│   ├── key_metrics.json           ← audit trail: every headline number, with a description
│   ├── dq_results.csv             ← 24 data-quality tests
│   ├── tableau_*.csv              ← extracts for the Tableau Public dashboard
│   └── *.csv                      ← every table behind every chart
└── data/raw/                      ← put the 9 Kaggle CSVs here (not committed)
```

## Methods at a glance

- **Data engineering:** raw → staging → star schema in SQL (window functions, deduplication, recursive date dimension), 24 dbt-style tests with blocking and warning severities, and an ER diagram.
- **Analytics:** order funnel, cohort retention, promise-gap and delivery-stage decomposition, hexbin geo-map.
- **Causal inference:** regression discontinuity (with bandwidth, placebo, donut, density and balance checks), OLS with seller fixed effects and cluster-robust SEs, propensity matching with a love plot, cross-fitted doubly-robust AIPW, and Kaplan–Meier with a log-rank test.
- **Heterogeneous effects:** T-learner plus doubly-robust pseudo-outcomes for segment-level CIs; a fix-first matrix.
- **Machine learning:** leak-free `merge_asof` history features, histogram gradient boosting, out-of-time validation, calibration, permutation importance, quantile regression.
- **Decision layer:** revenue at risk with low/base/high cases, lever sizing, validated priority lists.

## How to run

```bash
pip install -r requirements.txt
# download https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce and unzip into data/raw/
jupyter notebook The_Broken_Promise_Tax.ipynb     # full run takes about 2 minutes on a laptop
```

## Limitations

These are observational data, so the estimates assume no unmeasured confounding (mitigated by five agreeing estimators and seller fixed effects). The dataset can't show how ratings affect *other* customers' purchases, so the money estimate is a **floor**. The lever sizes rest on stated assumptions (see Part VIII). Lateness was higher in 2018 than in 2017, so the models need monthly recalibration.

**Data:** [Olist Brazilian E-Commerce Public Dataset](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce), CC BY-NC-SA 4.0. No employer data is used.
